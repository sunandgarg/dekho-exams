from urllib.parse import urlsplit

def accepted_target(text):
    if type(text) is not str or not 1 <= len(text) <= 128 or any(not 33 <= ord(char) <= 126 for char in text):
        raise ValueError("ASCII target bound")
    parsed = urlsplit(text)
    if (parsed.scheme != "https" or parsed.hostname != "learn.dekhoexams.in" or
        parsed.username is not None or parsed.password is not None or
        parsed.port not in (None, 443) or parsed.path != "/receipts" or
        parsed.query or parsed.fragment):
        raise ValueError("target policy")
    return "https://learn.dekhoexams.in/receipts"

print(accepted_target("https://learn.dekhoexams.in:443/receipts"))
for target in ("https://learn.dekhoexams.in.evil/receipts",
               "https://user@learn.dekhoexams.in/receipts", "\nhttps://learn.dekhoexams.in/receipts"):
    try:
        accepted_target(target)
    except ValueError:
        print("target rejected")
