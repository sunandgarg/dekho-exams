package in.dekhoexams.app;
import in.dekhoexams.billing.BillingRule;
public class Main { public static void main(String[] args) { System.out.println(BillingRule.total(3, 50)); } }
