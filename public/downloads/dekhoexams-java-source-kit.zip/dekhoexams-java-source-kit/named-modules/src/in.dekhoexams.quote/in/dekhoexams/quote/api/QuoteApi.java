package in.dekhoexams.quote.api;
public class QuoteApi { public static long amount() { return 150; } }
