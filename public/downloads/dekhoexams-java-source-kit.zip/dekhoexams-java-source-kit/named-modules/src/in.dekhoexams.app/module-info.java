module in.dekhoexams.app { requires in.dekhoexams.quote; }
