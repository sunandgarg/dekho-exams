package in.dekhoexams.app;
import in.dekhoexams.quote.api.QuoteApi;
public class Main { public static void main(String[] args) { System.out.println("quote="+QuoteApi.amount()); } }
