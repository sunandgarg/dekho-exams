package in.dekhoexams.adapter;
import in.dekhoexams.base.Quantity;
public class WrongReceiver extends Quantity {int read(Quantity other){return other.units;}}
