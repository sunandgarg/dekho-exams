package in.dekhoexams.adapter;
import in.dekhoexams.base.Quantity;
public class PrivateRead extends Quantity {int read(){return internal;}}
