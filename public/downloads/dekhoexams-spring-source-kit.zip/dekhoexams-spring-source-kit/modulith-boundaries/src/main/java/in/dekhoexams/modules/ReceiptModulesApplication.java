package in.dekhoexams.modules;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceiptModulesApplication { }
