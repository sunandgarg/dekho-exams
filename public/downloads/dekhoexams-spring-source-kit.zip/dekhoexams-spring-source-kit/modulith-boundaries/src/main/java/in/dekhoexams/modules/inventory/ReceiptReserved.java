package in.dekhoexams.modules.inventory;

public record ReceiptReserved(String receiptId, int units, int remaining) { }
