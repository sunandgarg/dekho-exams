package in.dekhoexams.invalidmodules;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvalidReceiptModulesApplication { }
