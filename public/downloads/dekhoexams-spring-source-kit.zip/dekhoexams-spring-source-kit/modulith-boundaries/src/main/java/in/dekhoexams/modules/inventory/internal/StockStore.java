package in.dekhoexams.modules.inventory.internal;

import in.dekhoexams.modules.inventory.InventoryQueries;

public final class StockStore implements InventoryQueries {
    @Override public int availableUnits(String receiptId) {
        return receiptId.equals("RC-47") ? 19 : 0;
    }
}
