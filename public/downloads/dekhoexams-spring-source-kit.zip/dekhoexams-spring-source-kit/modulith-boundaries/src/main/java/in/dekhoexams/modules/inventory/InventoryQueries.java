package in.dekhoexams.modules.inventory;

public interface InventoryQueries {
    int availableUnits(String receiptId);
}
